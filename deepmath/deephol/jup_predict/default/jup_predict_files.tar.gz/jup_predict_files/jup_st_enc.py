
def _proof_state_encoding(predictor, state_emb):
    return state_emb.goal_emb