"""Test Mock class for predictions.Predictions.

This class can be used for mocking concrete Predictions objects.
"""


from __future__ import absolute_import
from __future__ import division
# Import Type Annotations
from __future__ import print_function

import numpy as np

# jupyter imports
import jup_goal_emb
import jup_thm_emb
import jup_st_search
import jup_st_emb
import jup_st_enc
import jup_tac_sc
import jup_thm_sc

from deepmath.deephol import predictions




# TODO(smloos): Rename to MockPredictions.
class JupPredictions(predictions.Predictions):
  """Mock Class for predictions.Predictions."""

  def _batch_goal_embedding(self, goals):
    return jup_goal_emb._batch_goal_embedding(self, goals)

  def _batch_thm_embedding(self, thms):
    """From a list of string theorems, compute and return their embeddings."""
    return jup_thm_emb._batch_thm_embedding(self, thms)

  def proof_state_from_search(self, node):
    return jup_st_search._proof_state_from_search(self, node)

  def proof_state_embedding(self, state: predictions.ProofState):
    return jup_st_emb._proof_state_embedding(self, state)

  def proof_state_encoding(self, state_emb: predictions.EmbProofState):
    return jup_st_enc._proof_state_encoding(self, state_emb)

  def _batch_tactic_scores(self, goal_embeddings):
    return jup_tac_sc._batch_tactic_scores(self, goal_embeddings)

  def _batch_thm_scores(self, goal_embeddings, thm_embeddings, tactic_id=None):
    return jup_thm_sc._batch_thm_scores(self, goal_embeddings, thm_embeddings)

JUP_PREDICTOR = JupPredictions()
